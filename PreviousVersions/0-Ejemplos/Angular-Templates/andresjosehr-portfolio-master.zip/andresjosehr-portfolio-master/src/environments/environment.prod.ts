export const environment = {
  production: true,
  trackAnalyticID: "G-4ML1VNCP9T"
};
