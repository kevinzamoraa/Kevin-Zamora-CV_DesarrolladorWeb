Hello Guys,

Moss is a beautiful Multipurpose Ecommerce / Healthcare / CRM Admin template.

You can also use it for many more different software types.

We hope you would like to buy me and my team a coffee.

Demo Link <a href="https://htmlthemes.gitlab.io/admin" target="_blank">Click here for Demo</a>

To get installation & support just contact us on fiveonedigital@gmail.com

<a href="https://www.buymeacoffee.com/djdivesh007">Buy me a Coffee</a>

Here are some screen shots

Default Layout

<img width="1432" alt="default" src="https://user-images.githubusercontent.com/42273410/113285094-2aae0080-9308-11eb-8d63-15be25cbff42.png">

Horizontal Without Icons

<img width="1433" alt="horizontal-without-icons" src="https://user-images.githubusercontent.com/42273410/113285159-3f8a9400-9308-11eb-9495-f4ff8ed5946d.png">

Horizontal With Icons

<img width="1433" alt="horizontal" src="https://user-images.githubusercontent.com/42273410/113285175-45807500-9308-11eb-91b3-2fb8c45f808a.png">

Mini Sidebar

<img width="1434" alt="mini" src="https://user-images.githubusercontent.com/42273410/113285210-4fa27380-9308-11eb-9150-d37999a5cf73.png">

Overlay Sidebar

<img width="1433" alt="overlay" src="https://user-images.githubusercontent.com/42273410/113285219-529d6400-9308-11eb-9683-a0286cae3c31.png">
