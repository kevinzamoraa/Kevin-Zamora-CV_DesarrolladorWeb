export const environment = {
  production: true,
  firebaseConfig: {
    apiKey: "demo",
    authDomain: "blogsite-30c69.firebaseapp.com",
    databaseURL: "demo",
    projectId: "blogsite-30c69",
    storageBucket: "demo",
    messagingSenderId: "demo",
    appId: "demo",
  },
};
