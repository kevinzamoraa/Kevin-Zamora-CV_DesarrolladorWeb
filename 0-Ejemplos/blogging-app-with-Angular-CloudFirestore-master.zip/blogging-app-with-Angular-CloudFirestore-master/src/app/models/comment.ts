export class Comments {
    commentId: string;
    blogId: string;
    email: string;
    commentedBy: string;
    content: string;
    commentDate: any;
}
