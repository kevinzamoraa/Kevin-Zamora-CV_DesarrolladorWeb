export class AppUser {
    name: string;
    email: string;
    isAdmin: boolean;
    photoURL: string;
}
