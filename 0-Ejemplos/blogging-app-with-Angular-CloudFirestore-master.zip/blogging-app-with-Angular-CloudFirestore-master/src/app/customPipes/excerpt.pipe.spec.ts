import { ExcerptPipe } from './excerpt.pipe';

describe('ExcerptPipe', () => {
  it('create an instance', () => {
    const pipe = new ExcerptPipe();
    expect(pipe).toBeTruthy();
  });
});
