import { SlugPipe } from './slug.pipe';

describe('SlugPipe', () => {
  it('create an instance', () => {
    const pipe = new SlugPipe();
    expect(pipe).toBeTruthy();
  });
});
