# [Creative Commons Attribution 3.0 License](https://creativecommons.org/licenses/by/3.0/)

Copyright (c) [AppSeed](https://appseed.us/)

<br />

## You are allowed to:

- **Share** — copy and redistribute the material in any medium or format (unlimited copies)
- **Adapt** — remix, transform, and build upon the material for any purpose, even commercially.

> Note: `AppSeed` cannot revoke these freedoms as long as you follow the license terms.

<br />

## You are NOT allowed:

- **Remove Footer Attribution**

<br />

---
For more information regarding licensing, please contact the AppSeed Service < *support@appseed.us* >
