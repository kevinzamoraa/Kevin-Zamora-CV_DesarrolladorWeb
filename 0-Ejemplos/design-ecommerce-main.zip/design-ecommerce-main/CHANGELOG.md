# Change Log

## [1.0.3] 2023-03-22
### Changes

- New Components
  - Navigation Rotating Text
  - Testimonials. added 3 texts
  - Product Page, added Tabbed information 

## [1.0.2] 2023-03-21
### Changes

- Auth Pages:
  - SignIN, Register
- Added Video Components
  - Modal popup
  - Embeded Video

## [1.0.1] 2023-03-20
### Changes

- Tooling Update
- Extract Components (all files)

## [1.0.0] 2023-02-23
### Changes

- [Demo HTML](https://design-ecommerce.appseed-srv1.com/)
- [Demo FIGMA](https://bit.ly/figma-ecommerce) 
- BS Version `v5.2.3`
- License 
