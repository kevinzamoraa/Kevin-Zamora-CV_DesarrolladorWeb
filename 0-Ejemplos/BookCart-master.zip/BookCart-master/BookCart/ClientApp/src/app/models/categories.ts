export class Categories {
  categoryId: number;
  categoryName: string;
}
