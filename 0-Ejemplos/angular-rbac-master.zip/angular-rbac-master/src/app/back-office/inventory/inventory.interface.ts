export interface InventoryItem {
  sku: string;
  productName: string;
  stock: number;
  imageSrc: string;
}
