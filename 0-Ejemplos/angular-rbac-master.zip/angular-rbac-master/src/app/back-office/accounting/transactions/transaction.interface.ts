export interface Transaction {
  id: string;
  date: string;
  fromTo: string;
  description: string;
  amount: number;
}
