export type Role = 'Orders' | 'Inventory' | 'Accounting' | 'Manager';
